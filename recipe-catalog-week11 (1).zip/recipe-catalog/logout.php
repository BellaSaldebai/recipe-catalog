<?php
require_once 'includes/functions.php';

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

session_start();
$_SESSION['flash'] = ['type' => 'success', 'text' => 'Сіз жүйеден шықтыңыз.'];
header('Location: login.php');
exit;
